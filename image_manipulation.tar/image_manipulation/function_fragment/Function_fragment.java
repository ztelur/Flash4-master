package com.nju.Flash.image_manipulation.function_fragment;

/**
 * Created by randy on 14-3-12.
 */
public enum Function_fragment {
    pen_function,attribute_function
}
